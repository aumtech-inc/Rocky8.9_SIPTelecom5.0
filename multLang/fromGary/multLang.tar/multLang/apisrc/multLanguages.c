/*------------------------------------------------------------------------------
File:		multLanguages.c
Purpose:	Speak currency in multiple languages.
Author:		Aumtech, Inc.
Update:	djb 01/25/2002	Created the file.
------------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "Telecom.h"
#include "arcML.h"
#include "arcMLInternal.h"
#include "arcMLMnemonics.h"

#include "ispinc.h"
#include "loginc.h"

/*------------------------------------------------------------------------------
ML_SpeakCurrency():
------------------------------------------------------------------------------*/
int ML_SpeakCurrency(int zLanguage, int zParty, int zInterruptOption,
			char *zData, int zSync)
{
	static char	yMod[]="ML_SpeakCurrency";
	int			yRc=0;
	int			rc=0;
	long		mainBalance;
	char		minorBalance[3];
	char		hundredMillions[2],tenMillions[2],millions[2];
	char		hundredThousands[2],tenThousands[2],thousands[2];
	char		hundreds[2],tens[2],units[2];
	char		tenths[2],hundredths[2];
	static int	minutes;
	static int	seconds;
	char		minuteStr[8];
	char		secondStr[8];
	char		tmpSysVoxSelection[ARRAY_SIZE];
	char		balance[64];

	memset(minorBalance,		'\0',	sizeof(minorBalance));
	memset(hundredMillions,		'\0',	sizeof(hundredMillions));
	memset(tenMillions,			'\0',	sizeof(tenMillions));
	memset(millions,			'\0',	sizeof(millions));
	memset(hundredThousands,	'\0',	sizeof(hundredThousands));
	memset(tenThousands,		'\0',	sizeof(tenThousands));
	memset(thousands,			'\0',	sizeof(thousands));
	memset(hundreds,			'\0',	sizeof(hundreds));
	memset(tens,				'\0',	sizeof(tens));
	memset(units,				'\0',	sizeof(units));
	memset(tenths,				'\0',	sizeof(tenths));
	memset(hundredths,			'\0',	sizeof(hundredths));
	memset(minuteStr,			'\0',	sizeof(minuteStr));
	memset(secondStr,			'\0',	sizeof(secondStr));
	memset(tmpSysVoxSelection,	'\0',	sizeof(tmpSysVoxSelection));

	if (zData[0] == '\0')
	{
		yRc = UTL_VarLog(yMod, REPORT_NORMAL, 0, GV_Resource_Name, "TEL",
			GV_Application_Name, 
			ML_INVALID_PARAM, "Error: Empty data string received (%s).  Must "
			"be a valid integer.", zData);
		return(-1);
	}

	switch(zLanguage)
	{
		case ML_FRENCH:
			if (! gFrenchLoaded)
			{
				if ((yRc = mlLoadLanguage(zLanguage, ML_MALE)) != 0)
				{
					return(yRc);		/* message is logged in routine */
				}
			}
			break;
		default:
			gaVarLog(yMod, 0, "Error: Invalid language parameter received "
				"(%d).  Must be either ML_FRENCH (%d) or ML_SPANISH (%d).",
				zLanguage, ML_FRENCH, ML_SPANISH);
			return(-1);
	}
	gaVarLog(yMod, DEBUG,"Cash balance : (%s)", (char *)zData);

	mlParseBalance(zData, hundredMillions, tenMillions, millions,
			hundredThousands, tenThousands, thousands, hundreds, tens,
			units,tenths,hundredths);
	gaVarLog(yMod, DEBUG, "mlParseBalance(%s, %s, %s, %s, %s, %s, "
		"%s, %s, %s, %s, %s, %s)",
		zData,hundredMillions,tenMillions,millions,hundredThousands,
	    tenThousands,thousands,hundreds,tens,units,tenths,hundredths);

	mainBalance=atol(zData);
	strcpy(minorBalance, tenths);
	strcat(minorBalance, hundredths);
	gaVarLog(yMod, DEBUG,
			"mainBal <%ld> minorBal (%s)", mainBalance, minorBalance);

	rc=mlCheckSpecialNumber(hundredMillions,tenMillions,millions,hundredThousands,
	    tenThousands,thousands,hundreds,tens,units,tenths,
	    hundredths, zLanguage);
	gaVarLog(yMod, DEBUG, "%d = mlCheckSpecialNumber(%s, %s, %s, %s, %s, %s, "
		"%s, %s, %s, %s, %s, %d)", 
		rc, hundredMillions,tenMillions,millions,hundredThousands,
	    tenThousands,thousands,hundreds,tens,units,tenths,
	    hundredths, zLanguage);


	switch (rc)
	{
	case SPECIAL_NUMBER_1:
		mainBalance=mainBalance-100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption, PHRASE_TAG,
				PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		gaVarLog(yMod, DEBUG, "Successfully spoke phrase tag (%s)", "hundred");
		break;

	case SPECIAL_NUMBER_2:
		mainBalance=mainBalance-1000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_3:
		mainBalance=mainBalance-1100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_4:
		mainBalance=mainBalance-100000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_5:
		mainBalance=mainBalance-100100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_6:
		mainBalance=mainBalance-101000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_7:
		mainBalance=mainBalance-101100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_8:
		mainBalance=mainBalance-1000000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_9:
		mainBalance=mainBalance-1000100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_10:
		mainBalance=mainBalance-1001000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_11:
		mainBalance=mainBalance-1001100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_12:
		mainBalance=mainBalance-1100000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_13:
		mainBalance=mainBalance-1100100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_14:
		mainBalance=mainBalance-1101000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_15:
		mainBalance=mainBalance-1101100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_16:
		mainBalance=mainBalance-100000000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_17:
		mainBalance=mainBalance-100000100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_18:
		mainBalance=mainBalance-100001000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_19:
		mainBalance=mainBalance-100001100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_20:
		mainBalance=mainBalance-100100000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_21:
		mainBalance=mainBalance-100100100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_22:
		mainBalance=mainBalance-100101000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_23:
		mainBalance=mainBalance-100101100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_24:
		mainBalance=mainBalance-101000000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_25:
		mainBalance=mainBalance-101000100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_26:
		mainBalance=mainBalance-101001000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_27:
		mainBalance=mainBalance-101001100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_28:
		mainBalance=mainBalance-101100000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_29:
		mainBalance=mainBalance-101100100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_30:
		mainBalance=mainBalance-101101000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_31:
		mainBalance=mainBalance-101101100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPANISH_NUMBER:
		gaVarLog(yMod, DEBUG, "Speaking Spanish");
		if (mainBalance >= 1000)
		{
			switch (atol(thousands))
			{
			case 1:
				if ((yRc = TEL_Speak(zParty, zInterruptOption,
					PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-1000;
				break;
			case 2:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "2000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-2000;
				break;
			case 3:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "3000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-3000;
				break;
			case 4:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "4000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-4000;
				break;
			case 5:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "5000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-5000;
				break;
			case 6:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "6000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-6000;
				break;
			case 7:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "7000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-7000;
				break;
			case 8:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "8000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-8000;
				break;
			case 9:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "9000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-9000;
				break;
			}
		}
		if (atol(thousands) > 0 && mainBalance > 0 && mainBalance < 100)
		{
			if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
			{
				return(yRc);
			}
		}
		if (mainBalance >= 100 && mainBalance < 1000)
		{
			switch (atol(hundreds))
			{
			case 1:
				mainBalance=mainBalance-100;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "hundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "hundredPlus", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 2:
				mainBalance=mainBalance-200;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "twoHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "twoHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 3:
				mainBalance=mainBalance-300;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}

					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "threeHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "threeHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 4:
				mainBalance=mainBalance-400;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}

						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "fourHundred", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "fourHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 5:
				mainBalance=mainBalance-500;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "fiveHundred", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "fiveHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 6:
				mainBalance=mainBalance-600;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "sixHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "sixHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 7:
				mainBalance=mainBalance-700;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}

					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "sevenHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "sevenHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 8:
				mainBalance=mainBalance-800;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
								PHRASE_TAG, PHRASE_FILE, "and", zSync))
								!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "eightHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "eightHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 9:
				mainBalance=mainBalance-900;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
								PHRASE_TAG, PHRASE_FILE, "and", zSync))
								!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}

					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "nineHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "nineHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			}
			if (mainBalance > 0 && rc == PORTUGUESE_NUMBER)
			{
				if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
				{
					return(yRc);
				}
			}
		}
		break;
	case ORDINARY_NUMBER:
	case EXTRAORDINARY_NUMBER:
	default:
		break;

	} /* End switch special number type */

	gaVarLog(yMod, DEBUG, "mainBalance:(%d)", mainBalance);
	gaVarLog(yMod, DEBUG, "balance - zData:(%s)", zData);
	if (mainBalance > 0)
	{
		/* Speak remainder */
		sprintf(balance, "%ld", mainBalance);
		yRc = TEL_Speak(zParty, zInterruptOption, STRING, NUMBER,	
					balance, zSync);
	}
	if (atol(zData) > 0)
	{
		if ((yRc = mlPlayMainCurrencyUnit(zLanguage, mainBalance, zParty,
					zInterruptOption, zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
	}

	gaVarLog(yMod, 0, "Speak minor currency units (%s).", minorBalance);
	if (strcmp(minorBalance, "00"))
	{
		if (atol(zData) > 0)
		{
			gaVarLog(yMod, DEBUG, "speaking and ");
			if ((yRc = TEL_Speak(zParty, zInterruptOption, PHRASE_TAG,
					PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
			{
				return(yRc);
			}
		}

		gaVarLog(yMod, DEBUG, "speaking minorBalance (%s)", minorBalance);
		TEL_Speak(FIRST_PARTY, FIRST_PARTY_INTRPT, STRING, NUMBER,
					minorBalance, zSync);

		yRc = mlPlayMinorCurrencyUnit(zLanguage, atol(minorBalance), zParty,
				zInterruptOption, zSync);
		return(yRc);
	}

	return(0);
} /* END: ML_SpeakCurrency() */

/*------------------------------------------------------------------------------
ML_SpeakNumber():
------------------------------------------------------------------------------*/
int ML_SpeakNumber(int zLanguage, int zGender, int zParty, int zInterruptOption,
			char *zData, int zSync)
{
	static char	yMod[]="ML_SpeakNumber";
	int			yRc=0;
	int			rc=0;
	int			yCounter;
	long		mainBalance;
	char		hundredMillions[2],tenMillions[2],millions[2];
	char		hundredThousands[2],tenThousands[2],thousands[2];
	char		hundreds[2],tens[2],units[2];
	char		tenths[2],hundredths[2];
	static int	minutes;
	static int	seconds;
	char		minuteStr[8];
	char		secondStr[8];
	char		tmpSysVoxSelection[ARRAY_SIZE];
	char		balance[64];
	char		yPhraseDir[128];
	char		yDir[256];
	char		*pIspBase;
	static char	yIspBase[128];
	static char	yPhraseFile[256];

	
	switch (zGender)
	{
		case ML_MALE:
		case ML_FEMALE:
		case ML_NEUTRAL:
			break;
		default:
			gaVarLog(yMod, 0, "Error: Invalid gender parameter received "
				"(%d).  Must be either ML_MALE (%d), ML_FEMALE (%d), "
				"ML_NEUTRAL (%d).",
				zLanguage, ML_FRENCH, ML_SPANISH, ML_NEUTRAL);
			return(-1);
			break;
	}

	if (zData[0] == '\0')
	{
		gaVarLog(yMod, 0, "Error: Empty data string received (%s).  Must "
				"be a valid integer.", zData);
		return(-1);
	}
	for (yCounter = 0; zData[yCounter] != '\0'; yCounter++)
	{
		if ( ! isdigit(zData[yCounter]) )
		{
			gaVarLog(yMod, 0, "Error: Invalid data string received (%s).  Must "
				"be a valid integer.", zData);
			return(-1);
		}
	}
	memset(hundredMillions,		'\0',	sizeof(hundredMillions));
	memset(tenMillions,			'\0',	sizeof(tenMillions));
	memset(millions,			'\0',	sizeof(millions));
	memset(hundredThousands,	'\0',	sizeof(hundredThousands));
	memset(tenThousands,		'\0',	sizeof(tenThousands));
	memset(thousands,			'\0',	sizeof(thousands));
	memset(hundreds,			'\0',	sizeof(hundreds));
	memset(tens,				'\0',	sizeof(tens));
	memset(units,				'\0',	sizeof(units));
	memset(tenths,				'\0',	sizeof(tenths));
	memset(hundredths,			'\0',	sizeof(hundredths));
	memset(minuteStr,			'\0',	sizeof(minuteStr));
	memset(secondStr,			'\0',	sizeof(secondStr));
	memset(tmpSysVoxSelection,	'\0',	sizeof(tmpSysVoxSelection));

	switch(zLanguage)
	{
		case ML_FRENCH:
			if (! gFrenchLoaded)
			{
				if ((yRc = mlLoadLanguage(zLanguage, zGender)) != 0)
				{
					return(yRc);		/* message is logged in routine */
				}
			}
			break;
		default:
			gaVarLog(yMod, 0, "Error: Invalid language parameter received "
				"(%d).  Must be either ML_FRENCH (%d) or ML_SPANISH (%d).",
				zLanguage, ML_FRENCH, ML_SPANISH);
			return(-1);
	}
	gaVarLog(yMod, DEBUG,"Number to speak: (%s)", zData);

	mlParseBalance(zData, hundredMillions, tenMillions, millions,
			hundredThousands, tenThousands, thousands, hundreds, tens,
			units,tenths,hundredths);
	gaVarLog(yMod, DEBUG, "mlParseBalance(%s, %s, %s, %s, %s, %s, "
		"%s, %s, %s, %s, %s, %s)",
		zData,hundredMillions,tenMillions,millions,hundredThousands,
	    tenThousands,thousands,hundreds,tens,units,tenths,hundredths);

	mainBalance=atol(zData);
	gaVarLog(yMod, DEBUG,
			"mainBal *%ld) ", mainBalance);

	rc=mlCheckSpecialNumber(hundredMillions,tenMillions,millions,
		hundredThousands, tenThousands,thousands,hundreds,tens,units,tenths,
	    hundredths, zLanguage);
	gaVarLog(yMod, DEBUG, "%d = mlCheckSpecialNumber(%s, %s, %s, %s, %s, %s, "
		"%s, %s, %s, %s, %s, %d)", 
		rc, hundredMillions,tenMillions,millions,hundredThousands,
	    tenThousands,thousands,hundreds,tens,units,tenths,
	    hundredths, zLanguage);


	switch (rc)
	{
	case SPECIAL_NUMBER_1:
		mainBalance=mainBalance-100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption, PHRASE_TAG,
				PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		gaVarLog(yMod, DEBUG, "Successfully spoke phrase tag (%s)", "hundred");
		break;

	case SPECIAL_NUMBER_2:
		mainBalance=mainBalance-1000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_3:
		mainBalance=mainBalance-1100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_4:
		mainBalance=mainBalance-100000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_5:
		mainBalance=mainBalance-100100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_6:
		mainBalance=mainBalance-101000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_7:
		mainBalance=mainBalance-101100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_8:
		mainBalance=mainBalance-1000000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_9:
		mainBalance=mainBalance-1000100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_10:
		mainBalance=mainBalance-1001000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_11:
		mainBalance=mainBalance-1001100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_12:
		mainBalance=mainBalance-1100000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_13:
		mainBalance=mainBalance-1100100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_14:
		mainBalance=mainBalance-1101000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_15:
		mainBalance=mainBalance-1101100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_16:
		mainBalance=mainBalance-100000000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_17:
		mainBalance=mainBalance-100000100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_18:
		mainBalance=mainBalance-100001000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_19:
		mainBalance=mainBalance-100001100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_20:
		mainBalance=mainBalance-100100000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_21:
		mainBalance=mainBalance-100100100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_22:
		mainBalance=mainBalance-100101000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_23:
		mainBalance=mainBalance-100101100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_24:
		mainBalance=mainBalance-101000000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_25:
		mainBalance=mainBalance-101000100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_26:
		mainBalance=mainBalance-101001000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_27:
		mainBalance=mainBalance-101001100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_28:
		mainBalance=mainBalance-101100000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_29:
		mainBalance=mainBalance-101100100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_30:
		mainBalance=mainBalance-101101000;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPECIAL_NUMBER_31:
		mainBalance=mainBalance-101101100;
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "million", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "one", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "hundred", zSync)) != TEL_SUCCESS)
		{
			return(yRc);
		}
		break;

	case SPANISH_NUMBER:
		gaVarLog(yMod, DEBUG, "Speaking Spanish");
		if (mainBalance >= 1000)
		{
			switch (atol(thousands))
			{
			case 1:
				if ((yRc = TEL_Speak(zParty, zInterruptOption,
					PHRASE_TAG, PHRASE_FILE, "thousand", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-1000;
				break;
			case 2:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "2000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-2000;
				break;
			case 3:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "3000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-3000;
				break;
			case 4:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "4000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-4000;
				break;
			case 5:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "5000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-5000;
				break;
			case 6:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "6000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-6000;
				break;
			case 7:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "7000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-7000;
				break;
			case 8:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "8000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-8000;
				break;
			case 9:
				if ((yRc = TEL_Speak(zParty, zInterruptOption, STRING,
						NUMBER, "9000", zSync)) != TEL_SUCCESS)
				{
					return(yRc);
				}
				mainBalance=mainBalance-9000;
				break;
			}
		}
		if (atol(thousands) > 0 && mainBalance > 0 && mainBalance < 100)
		{
			if ((yRc = TEL_Speak(zParty, zInterruptOption,
				PHRASE_TAG, PHRASE_FILE, "and", zSync)) != TEL_SUCCESS)
			{
				return(yRc);
			}
		}
		if (mainBalance >= 100 && mainBalance < 1000)
		{
			switch (atol(hundreds))
			{
			case 1:
				mainBalance=mainBalance-100;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "hundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "hundredPlus", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 2:
				mainBalance=mainBalance-200;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "twoHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "twoHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 3:
				mainBalance=mainBalance-300;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}

					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "threeHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "threeHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 4:
				mainBalance=mainBalance-400;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}

						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "fourHundred", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "fourHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 5:
				mainBalance=mainBalance-500;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "fiveHundred", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "fiveHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 6:
				mainBalance=mainBalance-600;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "sixHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "sixHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 7:
				mainBalance=mainBalance-700;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}

					if ((yRc = TEL_Speak(zParty, zInterruptOption,
						PHRASE_TAG, PHRASE_FILE, "sevenHundred", zSync))
						!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "sevenHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 8:
				mainBalance=mainBalance-800;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
								PHRASE_TAG, PHRASE_FILE, "and", zSync))
								!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "eightHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "eightHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			case 9:
				mainBalance=mainBalance-900;
				if (mainBalance == 0)
				{
					if (atol(thousands) > 0)
					{
						if ((yRc = TEL_Speak(zParty, zInterruptOption,
								PHRASE_TAG, PHRASE_FILE, "and", zSync))
								!= TEL_SUCCESS)
						{
							return(yRc);
						}
					}

					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "nineHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				else
				{
					if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "nineHundred", zSync))
							!= TEL_SUCCESS)
					{
						return(yRc);
					}
				}
				break;
			}
			if (mainBalance > 0 && rc == PORTUGUESE_NUMBER)
			{
				if ((yRc = TEL_Speak(zParty, zInterruptOption,
							PHRASE_TAG, PHRASE_FILE, "and", zSync))
							!= TEL_SUCCESS)
				{
					return(yRc);
				}
			}
		}
		break;
	case ORDINARY_NUMBER:
	case EXTRAORDINARY_NUMBER:
	default:
		break;

	} /* End switch special number type */

	gaVarLog(yMod, DEBUG, "mainBalance:(%d)", mainBalance);
	gaVarLog(yMod, DEBUG, "balance - zData:(%s)", zData);
	if (mainBalance > 0)
	{
		/* Speak remainder */
		sprintf(balance, "%ld", mainBalance);
		yRc = TEL_Speak(zParty, zInterruptOption, STRING, NUMBER,	
					balance, zSync);
	}

	return(0);
} /* END: ML_SpeakNumber() */

