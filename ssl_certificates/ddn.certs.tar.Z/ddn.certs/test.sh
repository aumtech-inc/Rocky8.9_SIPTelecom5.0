#!~/bin/bash
#
#

collect()
{

	echo "What is your name?: "
	read name
	echo "What is your last name?: "
	read last
	echo "Hello $name $last"
}

collect << ANSWERS
deep
narsay
ANSWERS
